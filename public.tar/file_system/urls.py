from django.urls import path
import file_system.views as views

urlpatterns = [
    # path('register/', views.RegistrationViewSet.as_view({'get': 'list'}), name='auth_register'),
    # path('refresh/', TokenRefreshView.as_view(), name='token_refresh'),
    # path('refresh/', TokenVerifyView.as_view(), name='token_verify'),
    # path('login/', TokenObtainPairView.as_view(), name='auth_login'),
]
